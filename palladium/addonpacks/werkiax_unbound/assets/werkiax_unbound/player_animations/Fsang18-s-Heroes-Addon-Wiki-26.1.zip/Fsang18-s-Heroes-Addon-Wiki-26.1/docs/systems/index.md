Contains information about systems
